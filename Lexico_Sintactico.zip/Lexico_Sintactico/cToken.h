#ifndef CTOKEN_H_INCLUDED
#define CTOKEN_H_INCLUDED

using namespace std;

class cToken
{
protected:
    string nomToken;
    string lexema;

public:
    cToken(string nT, string l){
        this->nomToken=nT;
        this->lexema=l;
    }

    cToken(string tYL){
        this->nomToken=tYL;
        this->lexema=tYL;
    }

    void setNomToken(string nT){
        this->nomToken=nT;
    }
    void setLexema(string lex){
        this->lexema=lex;
    }
    string getNomToken(){
        return this->nomToken;
    }
    string getLexema(){
        return this->lexema;
    }
    void imprimeTokLex(){
        cout<<nomToken<<" ,"<<lexema<<endl;
    }

};

template <class T>
class cTokenNum : public cToken{
    T valorNum;

public:

    cTokenNum(string nomToken, string lexema) : cToken(nomToken, lexema){


    }
    void setValor(T vN){
        this->valorNum=vN;
    }
    T getValor(){
        return this->valorNum;
    }

    T convierteToNum(){

        stringstream aux(this->lexema);
        aux>>valorNum;
        return valorNum;
    }

};


#endif // CTOKEN_H_INCLUDED
