#ifndef ANALIZADORSINTACTICO_H_INCLUDED
#define ANALIZADORSINTACTICO_H_INCLUDED

class cAnalisisSintactico{
int i;
public:

    cAnalisisSintactico(){
    i=20;
}

void imp(){
    
    std::cout<<i;
}
};
#endif
