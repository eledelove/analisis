#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <list>
#include <string.h>
#include <sstream>
#include <vector>
#include <map>
#include "analizadorSintactico.h"
#include "cToken.h"

using namespace std;



class cAnalisisLexico{

    ifstream in;
    ofstream out;
    ifstream palabrasReservadas;
    list<string> listaPalabras;
    vector<cToken*> bufferToken;
    typedef void (cAnalisisLexico::*punteroFuncionToken)();
    char c;

    map<char,punteroFuncionToken> tipoToken;

    char* archivoSalida;

public:
    cAnalisisLexico(){}


    bool esReservada(char* id){
        bool reservada = false;

        for(list<string>::iterator it = listaPalabras.begin(); it != listaPalabras.end(); it ++){
            if(strcmp(id, (*it).c_str())==0)
            {
                reservada = true;
                break;

            }
        }
        return reservada;
    }

    cAnalisisLexico (char* s, char* salida){
        in.open(s);

        try{
            if(in.fail())
                throw 1;
            cout<<"Exito al abrir el archivo"<<s<<endl;

            palabrasReservadas.open("palabrasReservadas.txt");

            if(palabrasReservadas.fail())
                throw 2;
            cout<<"Exito al abrir el archivo palabrasReservadas.txt"<<endl;

            string cad;

            while(!palabrasReservadas.eof())
            {
                palabrasReservadas>>cad;
                listaPalabras.push_back(cad);
            }

            out.open(salida);
        }catch(int i){
            if(i==1)
                cout<<"Error al abrir el archivo para analizar"<<endl;
            else if(i==2)
                cout<<"Error al abrir archivo de palabrasReservadas.txt"<<endl;
            else
                cout<<"Error no definido"<<endl;
        }
        cout<<"Constructor dos"<<endl;
    }

   vector <cToken*> getTokens(){


        return this->bufferToken;
    }


    void tokenID(){
        string id;
        id = c;
        c = in.get();

        while(isalnum(c) || c=='_')
        {
            id += c;
            c = in.get();
        }

        if(!esReservada((char*)id.c_str())){
            out<<"(TokID,"<<id<<")";
            bufferToken.push_back(new cToken("TokID", id));
        }
        else{
            out<<"(TokPR,"<<id<<")";
            bufferToken.push_back(new cToken("PalabraRes", id));
        }

        in.unget();
    }

    void tokenComentario()
    {
        c = in.get();

        if(c=='/')
        {
            c = in.get();
            while(c!='\n')
                c = in.get();

            in.unget();
            out<<"TokComentarioCorto";
        }
        else if(isalpha(c))
        {
            out<<"TokDiv";
            bufferToken.push_back(new cToken("tokDiv", "/"));
            in.unget();
        }
        else if(c=='*')
        {
            char d;
            do
            {
                while(in.get()!='*');
                in.unget();
                while(in.get()=='*');
                in.unget();
                if((d=in.get())=='/')
                {
                    out<<"TokComentarioLargo"<<endl;
                    in.unget();
                    break;
                }
            }while(d!='/');
        }
    }


    void tokenPI(){
        out<<"TokPI(";
        bufferToken.push_back(new cToken("tokenParenIzq", "("));
    }

    void tokenPyC(){
        out<<"TokPyC"<<endl;
        bufferToken.push_back(new cToken("tokenPyC", ";"));
    }

    void tokenMenor(){
        out<<"TokMenor";
        bufferToken.push_back(new cToken("tokenMenor", "<"));
    }

    void tokenMayor(){
        out<<"TokMayor";
        bufferToken.push_back(new cToken("tokenMayor", ">"));
    }

    void tokenCorIzq(){
        out<<"TokLlave{";
        bufferToken.push_back(new cToken("tokenCorIzq", "{"));
    }
    void tokenParenIzq(){
        out<<"TokParenIzq";
        bufferToken.push_back(new cToken("tokenParenIzq", "("));
    }
    void tokenParenDer(){
        out<<"TokParenDer";
        bufferToken.push_back(new cToken("tokenParenDer", ")"));
    }

    void tokenNumero(){

        string num;
        num = c;
        c = in.get();
        if(c == '+'){
            out<<"(TokIncre,++)";
            bufferToken.push_back(new cToken("tokenIncre", "++"));
        }
        else if(c == '-'){
            out<<"(TokDecre,--)";
            bufferToken.push_back(new cToken("tokenDecre", "--"));
        }
        else if(c == '='){
            out<<"(TokIncre,+=)";
            bufferToken.push_back(new cToken("tokenIncre", "+="));
        }
        else if(isalpha(c) && toupper(c)!='E'){
            out<<"(TokOpArit,"<<c;
           // bufferToken.push_back(new cToken("tokenOpArit", c));
        }
        else
        {
            while(isdigit(c))
            {
                num += c;
                c = in.get();
            }
            if(c == '.')
            {
                num += c;
                c = in.get();

                while(isdigit(c))
                {
                    num += c;
                    c = in.get();
                }
                if (toupper(c)!='E'){
                    out <<"TokFloat"<<num<<endl;
                    bufferToken.push_back(new cTokenNum<float>("tokenFloat", num));
                }
                else
                {
                    parteFinalAutomata:
                        num += c;
                        c = in.get();

                        if(c == '+' || c == '-' || isdigit(c))
                        {
                            num += c;
                            c = in.get();
                            while(isdigit(c))
                            {
                                num += c;
                                c = in.get();
                            }
                            out<<"TokNumExp"<<num<<endl;
                            bufferToken.push_back(new cTokenNum<double>("tokNumExp", num));
                        }
                        else
                            out<<"Error en formato exponencial";
                }
            }

            else if(toupper(c) == 'E')
                goto parteFinalAutomata;

            else{
                out<<"(TokInt,"<<num;
                bufferToken.push_back(new cTokenNum<int>("tokInt", num));
            }

            in.unget();
        }
    }

    void tokenAsigTiny(){

        c = in.get();
        if(c =='='){
        out<<"(TokAisgTiny,"<<c;
        bufferToken.push_back(new cTokenNum<int>("tokAsigTiny", ":="));
        }
    }

    /*void tokenCadena(){

        string cad;
        cad = c;
        c = in.get();

        while((isalnum(c) || c == ' ') && c != '"')
        {
            cad += c;
            c = in.get();
        }
        //if(c == '"') cad += c;
        out<<"(TokenCadena,"<<cad<<")";

        in.unget();
    }*/


    void recuperaTokens(){

        string id;

        //tipoToken['('] = &cAnalisisLexico::tokenPI;
        tipoToken[':'] = &cAnalisisLexico::tokenAsigTiny;
        tipoToken[';'] = &cAnalisisLexico::tokenPyC;
        tipoToken['('] = &cAnalisisLexico::tokenParenIzq;
        tipoToken[')'] = &cAnalisisLexico::tokenParenDer;
        tipoToken['<'] = &cAnalisisLexico::tokenMenor;
        tipoToken['>'] = &cAnalisisLexico::tokenMayor;
        tipoToken['{'] = &cAnalisisLexico::tokenCorIzq;
        tipoToken['a'] = &cAnalisisLexico::tokenID;
        tipoToken['_'] = tipoToken['a'];

        for(int i = 97; i <= 122; i++)
            tipoToken[(char)i] = tipoToken['a'];
        for(int i = 65; i <= 90; i++)
            tipoToken[(char)i] = tipoToken['a'];

        tipoToken['/'] = &cAnalisisLexico::tokenComentario;
        tipoToken['+'] = &cAnalisisLexico::tokenNumero;
        tipoToken['-'] = tipoToken['+'];

       //x tipoToken['"'] = &cAnalisisLexico::tokenCadena;
        //tipoToken[' '] = tipoToken['"'];


        for(int i = 48; i <= 57; i++)
            tipoToken[(char)i] = tipoToken['+'];

        map<char, punteroFuncionToken>::iterator it;
        while(!in.eof())
        {

            c = in.get();

            if(in.eof() || in.fail()) break;

            it=tipoToken.find(c);
            if(it!=tipoToken.end())
            (this->*tipoToken[c])();

            else
                out<<c;
        }
    }

};

/*class cAnalisisSintactico{

};*/


int main(int nargs, char** args){

    const char * sal = "miAnalisis.txt";

    if(nargs == 3)
        sal = args[2];



    cAnalisisLexico analisis1(args[1], (char*)sal);
    analisis1.recuperaTokens();

    cAnalisisSintactico p(analisis1.getTokens());



    return 0;
}

